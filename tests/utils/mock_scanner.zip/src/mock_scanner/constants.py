from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent.parent
DETECTOR_TEST_PATH = Path(__file__).parent / "detector_tests"
